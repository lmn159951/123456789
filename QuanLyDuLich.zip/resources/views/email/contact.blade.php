<!DOCTYPE html>
<html>
<head>
 <title>Go travel</title>
</head>
<body>
 
<p>Họ tên : {{ $mailData['name'] }}</p>
<p>Email : {{ $mailData['email'] }}</p>
<p>{{ $mailData['comment'] }}</p>
 
</body>
</html> 
