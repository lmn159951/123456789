<!DOCTYPE html>
<html>
<head>
 <title>Go travel</title>
</head>
<body>
 
<p>
    Link khôi phục tài khoản <a href="{{ $mailData['link'] }}">Click tại đây</a>
</p>
 
</body>
</html> 
